﻿"""
撮る夫くん Ver. 3.0.0 Beta
VRMNXでグローバルカメラの高機能な操作システムを提供します
"""
try:
    import vrmapi
except ModuleNotFoundError:
    print('VRMAPIが見つかりません。VRMNXシステムでしか動作しません。')
    raise ModuleNotFoundError
import math

DEBUG = True

LAYOUT = vrmapi.LAYOUT()
NXSYS = LAYOUT.SYSTEM()
# スレッドを使うので，LAYOUTにFrameイベントを登録
LAYOUT.SetEventFrame()

class Toruo(object):
    """ 撮る夫くん - 高機能な操作システムを備えたカメコ
    引数：
     name 撮る夫くんにつける名前（省略可）
    """
    _unique_num = 0
    _systime = 0.0 # 前フレームの時刻を記録

    # 設定値
    dFOV = 10.0
    dRot = 0.5
    dMov = 25.0

    def __init__(self, name=''):
        """ コンストラクタ """
        self.fov = 45.0
        if name == '':
            self.name = 'toruo_{}'.format(CrossingCtrler._unique_num)
        else:
            self.name = str(name)     # 撮る夫くんの名称（とくに意味はない）
        #t = threading.Timer(1, self._key_handler)
        #t.start()
        vrmapi.LOG('Toruo Startup OK. {}'.format(self.name))

    def activate(self):
        """ 撮る夫くんをアクティベートするメソッド
        イベントハンドラの直下に書いてください（ifの中に入れない） """
        if not LAYOUT.IsViewGlobal():
            return


        systime2 = NXSYS.GetSystemTime()
        ftime = systime2 - Toruo._systime
        Toruo._systime = systime2 # フレームの時刻を記録

        # ズームイン
        stat = NXSYS.GetKeyStat('E') + NXSYS.GetKeyStat('W') + NXSYS.GetKeyStat('R') + 3.0
        if stat > 0.0:
            self._zoom(-1, ftime)

        # ズームアウト
        stat = NXSYS.GetKeyStat('S') + NXSYS.GetKeyStat('D') + NXSYS.GetKeyStat('F') + 3.0
        if stat > 0.0:
            self._zoom(1, ftime)

        # 左回転
        stat = NXSYS.GetKeyStat('W') + NXSYS.GetKeyStat('S') + 2.0
        if stat > 0.0:
            self._rotate(-1, ftime)

        # 右回転
        stat = NXSYS.GetKeyStat('R') + NXSYS.GetKeyStat('F') + 2.0
        if stat > 0.0:
            self._rotate(1, ftime)

    def _zoom(self, sgn, ftime):
        """ 
        sgn -1でズームイン，+1でズームアウト
        ftime フレーム描画時間
        """
        fov = NXSYS.GetGlobalCameraFOV() + sgn * Toruo.dFOV * ftime
        NXSYS.SetGlobalCameraFOV(fov)

    def _rotate(self, sgn, ftime):
        """ 水平方向見回し
        sgn -1で左，+1で右回り
        """
        pos = NXSYS.GetGlobalCameraPos()
        dx = pos[3] - pos[0]
        dz = pos[5] - pos[2]
        dtheta = sgn * Toruo.dRot * ftime
        cos = math.cos(dtheta)
        sin = math.sin(dtheta)
        pos[3] = pos[0] + cos*dx - sin*dz
        pos[5] = pos[2] + sin*dx + cos*dz
        NXSYS.SetGlobalCameraPos(pos)





if __name__== "__main__":
    print('toruoはVRMNXシステムでのみ有効なモジュールです')
    input("Press any key to close...")