﻿"""
撮る夫くん Ver. 3.0.1 Beta
VRMNXでグローバルカメラの高機能な操作システムを提供します
v.3.0.0 Beta    NX用初版
v.3.0.1 Beta    被写界深度に対応
"""
try:
    import vrmapi
except ModuleNotFoundError:
    print('VRMAPIが見つかりません。VRMNXシステムでしか動作しません。')
    raise ModuleNotFoundError
from math import sin,cos,tan,sqrt, pi
# from threading import Thread, Timer
# from time import sleep
from random import triangular

DEBUG = True

LAYOUT = vrmapi.LAYOUT()
NXSYS = LAYOUT.SYSTEM()
IMGUI = vrmapi.ImGui()
# LAYOUTにFrameイベントを登録
LAYOUT.SetEventFrame()

_PARENT = None     # 親オブジェクト
_systime = 0.0 # 前フレームの時刻を記録
_shakemode = [False] # Trueで手ブレON
_guidisp = 0       # TrueでGUI操作盤を表示
_shake_vt = 0.0 # 手ブレの累積量
_shake_hr = 0.0
_shake_dvt = 0.0 # 手ブレの差分
_shake_dhr = 0.0
_shake_evid = None

# DOF(被写界深度)がらみのパラメタ
_fov = [45.0]
_depth = [sqrt(1.0/512.0)]  # 合焦中心のルート
_fnum = [12.0]        # F値
_delta = [0.0008, 0.08]
_blur = [1.0]



# 設定値（公開プロパティ）
dFOV = 10.0
dRot = 0.5
dMov = 25.0
shake_factor = 0.1
shake_freq = 4.0

vrmapi.LOG('撮る夫くん(3.0.1) stand by.')

def setfactor(rotate=0.5, fov=10.0, move=25.0):
    global dRot
    global dFOV
    global dMov
    dRot = rotate
    dFOV = fov
    dMov = move

def setshakemode(mode=False):
    """ mode=Trueで手ブレON """
    global _shakemode
    global _shake_hr
    global _shake_vt
    _shake_vt = 0.0 # 手ブレ量をリセット
    _shake_hr = 0.0
    _shakemode[0] = mode
    _update_shake()

def _update_shake():
    global _shake_dhr
    global _shake_dvt
    global _shake_evid
    _shake_dhr = triangular(-1*shake_factor, shake_factor)
    _shake_dvt = triangular(-1*shake_factor, shake_factor)
    mode = _shakemode[0]
    vrmapi.LOG("test {}".format(mode))
    if mode:
        _shake_evid = _PARENT.SetEventAfter(triangular(0.0, 1.0/shake_freq))
            
def activate(obj, ev, param):
    """ 撮る夫くんをアクティベートするメソッド
    イベントハンドラの直下に書いてください（ifの中に入れない） """
    if ev == 'init':
        global _PARENT
        _PARENT = obj
        obj.SetEventKeyDown('P')
        return
    if not LAYOUT.IsViewGlobal():
        return
    if param['eventid'] == _shake_evid:
        # (Afterイベント)
        _update_shake()
        return
    if ev == 'keydown':
        if param['keycode'] == 'P':
            # GUI表示をON/OFF
            global _guidisp
            _guidisp = 1
            vrmapi.LOG('KEYDOWN P')
        return

    if ev != 'frame':
        return
    if _guidisp:
        _dispgui()
    ftime = _updateframetime(param['eventtime'])
    campos = NXSYS.GetGlobalCameraPos()

    # ズームイン
    stat = NXSYS.GetKeyStat('E') + NXSYS.GetKeyStat('W') + NXSYS.GetKeyStat('R') + 3.0
    if stat > 0.0:
        _zoom(-1, ftime)

    # ズームアウト
    stat = NXSYS.GetKeyStat('S') + NXSYS.GetKeyStat('D') + NXSYS.GetKeyStat('F') + 3.0
    if stat > 0.0:
        _zoom(1, ftime)

    # 左回転
    stat = NXSYS.GetKeyStat('W') + NXSYS.GetKeyStat('S') + 2.0
    if stat > 0.0:
        _rotate(campos, -1, ftime)

    # 右回転
    stat = NXSYS.GetKeyStat('R') + NXSYS.GetKeyStat('F') + 2.0
    if stat > 0.0:
        _rotate(campos, 1, ftime)

    # ブレ計算
    if _shakemode[0]:
        global _shake_hr
        global _shake_vt
        _shake_hr += _shake_dhr * dRot * ftime
        _shake_vt += _shake_dvt * dRot * ftime

        _rotate(campos, _shake_dhr, ftime)
        _rotatevt(campos, _shake_dvt, ftime)

        """ 追尾モードのとき 累積ブレ量を足す 
        _rotate(campos, _shake_hr, 1.0)
        _rotatevt(campos, _shake_vt, 1.0)
        """

    NXSYS.SetGlobalCameraPos(campos)

def _updateframetime(time_now):
    global _systime
    ftime = time_now - _systime
    _systime = time_now # フレームの時刻を記録
    return ftime

def _zoom(sgn, ftime):
    """ 
    sgn -1でズームイン，+1でズームアウト
    ftime フレーム描画時間
    """
    global _fov
    _fov[0] = NXSYS.GetGlobalCameraFOV() + sgn * dFOV * ftime
    NXSYS.SetGlobalCameraFOV(_fov[0])

def _rotate(campos, sgn, ftime):
    """ 水平方向見回し
    sgn -1で左，+1で右回り
    """
    # list campos はMutableなので返り値を取らなくていい
    dx = campos[3] - campos[0]
    dz = campos[5] - campos[2]
    dtheta = sgn * dRot * ftime
    cos_ = cos(dtheta)
    sin_ = sin(dtheta)
    campos[3] = campos[0] + cos_*dx - sin_*dz
    campos[5] = campos[2] + sin_*dx + cos_*dz

def _rotatevt(campos, sgn, ftime):
    """ 垂直見回し """
    x = sqrt((campos[3]-campos[0])**2 + (campos[5]-campos[2])**2)
    y = campos[4]-campos[1]
    alpha = tan(sgn * dRot * ftime)
    campos[4] = (y + x*alpha)/(1 - y/x*alpha) + campos[1] # tan加法定理の変形

def _camveclen(campos):
    sq = (campos[3]-campos[0])**2 + (campos[4]-campos[1])**2 + (campos[5]-campos[2])**2
    return sqrt(sq)

def _focus():
    NXSYS.SetGlobalCameraFOV(_fov[0])
    d1 = _depth[0]**4
    d2 = _fnum[0] * tan(_fov[0]*pi/180.0)**2 / 100.0
    NXSYS.SetFocusParam(d1+_delta[0]*d2,d1-_delta[0]*d2,d1+_delta[1]*d2,d1-_delta[1]*d2, _blur[0])

def _dispgui():
    global _shakemode
    global _fov
    global _depth
    global _fnum
    IMGUI.Begin("ToruoWin", "撮る夫くん")
    # IMGUI.Text('FOV={}'.format(NXSYS.GetGlobalCameraFOV()))
    action = False
    action += IMGUI.SliderFloat("zoom", "FOV(ズーム角度)", _fov, 10.0, 135.0)
    action += IMGUI.SliderFloat("focus", "合焦中心", _depth, 0.1, 1.0)
    action += IMGUI.SliderFloat("fnum", "絞り", _fnum, 1.0, 50.0)
    action += IMGUI.SliderFloat("blur", "ぼけの強さ", _blur, 0.0, 2.0)
    if action:
        _focus()
    IMGUI.Separator()
    if IMGUI.Checkbox("shake", "手ブレモード", _shakemode):
        setshakemode(_shakemode[0])

    if IMGUI.Button("closer", "メニューを閉じる"):
        global _guidisp
        _guidisp = 0

    IMGUI.End()


if __name__== "__main__":
    print('toruoはVRMNXシステムでのみ有効なモジュールです')
    input("Press any key to close...")